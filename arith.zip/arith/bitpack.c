#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include "except.h"
#include "bitpack.h"
#include "math.h"


Except_T Bitpack_Overflow = { "Overflow packing bits" };

int main(int argc, char *argv[])
{
        (void) argc;
        (void) argv;
        // try {
        //     assert(Bitpack_fitsu(5, 3));
        // }
        // catch {
        //     RAISE(Bitpack_Overflow);
        // }
        assert(Bitpack_fitsu(5, 3));
        assert(!Bitpack_fitsu(8, 3));
        assert(Bitpack_fitsu(0, 3));
       
        assert(!Bitpack_fitss(5,3)); 
        assert(!Bitpack_fitss(4,3));
        assert(Bitpack_fitss(2,3)); 
        assert(Bitpack_fitss(-2,3)); 
        assert(!Bitpack_fitss(-5,3)); 
        Bitpack_getu(0x3f4, 6, 2); 
        Bitpack_gets(0x3f4, 6, 2); 
        return 0;
}

bool Bitpack_fitsu(uint64_t n, unsigned width) {
        // printf("%f", pow(2, 64) - 1);
        if (width > 64) {
                RAISE(Bitpack_Overflow); 
        }
        printf("%lu\n", ((uint64_t)1 << width) - 1);
        if(width == 0 || width > 64 || n > ((uint64_t)1 << width) - 1) {
            return false; 
        } 
        return true;
}

bool Bitpack_fitss(int64_t n, unsigned width) {
        // printf("%lu\n", ((int64_t)1 << width) - 1);
        if(width > 64) {
                RAISE(Bitpack_Overflow); 
        }
        if(width == 0 || n > ((int64_t)1 << width) / 2 - 1 ||
           n < - (((int64_t)1 << width) / 2)) {
                return false; 
        } 
        return true;
}
uint64_t Bitpack_getu(uint64_t word, unsigned width, unsigned lsb) {
        assert(width <= 64 && width + lsb <= 64);
        uint64_t mask = ~0;
        mask = mask >> (64 - width) << lsb;
        printf("mask is: %lu\n", mask);
        uint64_t bitpack = (word & mask) >> lsb;       
        printf("bitpack obtained is: %lu\n", bitpack);
        return bitpack; 
}
int64_t Bitpack_gets(uint64_t word, unsigned width, unsigned lsb) {
        assert(width <= 64 && width + lsb <= 64);
        int64_t mask = ~0;
        mask = ~(mask >> (64 - width) << lsb);
        printf("mask is: %lu\n", mask);
        int64_t bitpack = (word & mask) >> lsb;       
        printf("bitpack obtained is: %lu\n", bitpack);
        return bitpack; 
}




// 0x3f4
// 0000000000000000000000000000000000000000000000000000000011111110100

// 1111111111111111111111111111111111111111111111111111111111111111111





// 0000001111111111111111111111111111111111111111111111111111111111111



// 1111000000000000000000000000000000000000000000000000000000000000011
// 0000000000000000000000000000000000000000000000000000000011111110100


// 0011 1111 0100


// 111101

// 111111111111;


// uint32_t mask = ((1 << width) - 1) << lsb 
// uint32_t value = mask && word >> lsb
// lsb = 2
// width = 6

// 0011 1111 0100



// 111101
// 1 + 4 + 8 + 16 + 32 = 61

// 111101
// 1 + 4 + 8 + 16 - 32 = = -3
